jQuery(function ($) {
    $('.counter').each(function () {
        $(this).prop('Counter', 0).animate({
            Counter: $(this).text()
        }, {
            duration: 4000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });
});

// wow js
jQuery(function ($) {
    new WOW().init();
});

// comingsoon page countdown
(function () {
    if (document.getElementById("days") !== null) {
        const second = 1000,
            minute = second * 60,
            hour = minute * 60,
            day = hour * 24;

        let today = new Date(),
            dd = String(today.getDate()).padStart(2, "0"),
            mm = String(today.getMonth() + 1).padStart(2, "0"),
            yyyy = today.getFullYear(),
            nextYear = String(yyyy + 1),
            dayMonth = "10/24/",
            birthday = dayMonth + yyyy;

        today = mm + "/" + dd + "/" + yyyy;
        if (today > birthday) {
            birthday = dayMonth + nextYear;
        }

        const countDown = new Date(birthday).getTime(),
            x = setInterval(function () {
                const now = new Date().getTime(),
                    distance = countDown - now;

                let days = Math.floor(distance / (day));
                let hours = Math.floor((distance % (day)) / (hour));
                let minutes = Math.floor((distance % (hour)) / (minute));
                let seconds = Math.floor((distance % (minute)) / second);

                document.getElementById("days").innerText = days;
                document.getElementById("hours").innerText = hours;
                document.getElementById("minutes").innerText = minutes;
                document.getElementById("seconds").innerText = seconds;

                if (distance < 0) {
                    clearInterval(x);
                    var items = document.querySelectorAll(".compaign_countdown");
                    for (var i = 0; i <= items.length; i++) {
                        if (typeof items[i] !== 'undefined') {
                            items[i].style.display = "none";
                        }
                    }
                }
            }, 0)
    }
})();

// checkout page active tabs
(function () {
    const steps = document.querySelectorAll('.checkout-steps li');
    const contents = document.querySelectorAll('.step-content');

    function showStep(stepNumber) {
        steps.forEach(s => s.classList.remove('active'));
        contents.forEach(c => c.classList.add('d-none'));

        document.querySelector(`.checkout-steps li[data-step="${stepNumber}"]`).classList.add('active');
        document.querySelector(`.step-${stepNumber}`).classList.remove('d-none');
    }

    steps.forEach(step => {
        step.addEventListener('click', () => {
            const num = step.getAttribute('data-step');
            showStep(num);
        });
    });

    document.querySelectorAll('.next-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const activeStep = document.querySelector('.checkout-steps li.active');
            let next = parseInt(activeStep.getAttribute('data-step')) + 1;
            if (next <= steps.length) showStep(next);
        });
    });

    document.querySelectorAll('.prev-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const activeStep = document.querySelector('.checkout-steps li.active');
            let prev = parseInt(activeStep.getAttribute('data-step')) - 1;
            if (prev >= 1) showStep(prev);
        });
    });
})();